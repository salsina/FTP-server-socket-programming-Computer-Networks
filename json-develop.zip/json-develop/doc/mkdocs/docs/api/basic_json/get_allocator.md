# basic_json::get_allocator

```cpp
static allocator_type get_allocator();
```

Returns the allocator associated with the container.
    
## Return value

associated allocator

## Version history

- Unknown.
